# Yeelight Smart Home

Open Agent Skills package for version 0.1.1.

This package depends on the separately installed `yeelight-home` Runtime and does not bundle Runtime binaries, Runtime source, installer scripts, raw internal docs or credentials.
