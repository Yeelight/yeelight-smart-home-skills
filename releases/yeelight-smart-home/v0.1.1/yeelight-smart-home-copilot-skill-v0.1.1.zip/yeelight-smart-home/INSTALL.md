# Install Yeelight Smart Home for GitHub Copilot

Copy this directory to one of the supported Agent Skills locations, for example:

- `.github/skills/yeelight-smart-home`
- `.agents/skills/yeelight-smart-home`

If using GitHub CLI skill workflows, publish or install from the reviewed repository path after maintainer approval.
