# Yeelight Smart Home

Claude Skill package for version 0.1.0.

This package depends on the separately installed `yeelight-home` Runtime and does not bundle Runtime binaries, Runtime source, installer scripts, raw internal docs or credentials.
