# Install Yeelight Smart Home for Claude

Upload the generated ZIP that contains the `yeelight-smart-home` directory, or install it through a Claude plugin/skill workflow supported by your workspace.

External upload and review remain manual follow-up steps for this release system.
